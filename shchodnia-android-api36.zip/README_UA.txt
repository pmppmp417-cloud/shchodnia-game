ЩОДНЯ — Android project

Цей проєкт упаковує вебгру у простий Android WebView-застосунок.
Для Google Play потрібен release signing key і підписаний AAB.

GitHub Actions файл: .github/workflows/build.yml
Він збирає release AAB після ручного запуску workflow.

ВАЖЛИВО: перед публікацією треба створити власний keystore та налаштувати підпис release. Не публікуйте AAB без підпису вашим ключем.
